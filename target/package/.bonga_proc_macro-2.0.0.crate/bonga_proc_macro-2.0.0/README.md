# bonga
cargo check

cargo build

cd examples
cargo run
